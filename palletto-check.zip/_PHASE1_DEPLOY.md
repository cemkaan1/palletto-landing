# Palletto – Phase 1 Deploy (Fundament + Startseite)

## Was drin ist
- index.html            → neue Startseite, jetzt mit KOMPILIERTEM CSS (kein Tailwind-CDN mehr)
- assets/palletto.css   → ein CSS-File (23 KB, ersetzt das 400-KB-CDN-JS) → Top PageSpeed
- assets/fonts/*.woff2   → selbst-gehostete Fonts (DSGVO)
- assets/img/*.webp      → echte App-Screenshots + Founder-Foto
- robots.txt            → KI-Crawler (GPTBot, ClaudeBot, PerplexityBot, Google-Extended …) erlaubt
- sitemap.xml           → alle 27 URLs (Seiten + Blog), Test-Seiten raus
- llms.txt              → für ChatGPT/Perplexity, sauberes Standard-Format
- vercel.json           → Cache-Header (1 Jahr für /assets) + Security-Header

## So deployen (Repo-Wurzel palletto-landing)
1. Diese Zip im Repo-Root entpacken (überschreibt index.html/robots.txt/sitemap.xml/llms.txt, fügt vercel.json + assets/ hinzu):
   unzip -o palletto-phase1.zip -d .
2. Test-/Utility-Seiten löschen (sollen nicht ranken):
   git rm demoindex.html indexkopie.html og-image.html
3. Stagen + pushen:
   git add index.html robots.txt sitemap.xml llms.txt vercel.json assets/palletto.css assets/fonts assets/img
   git commit -m "Phase 1: kompiliertes CSS (PageSpeed), KI-Crawler, Sitemap, Schema, Infra"
   git push origin main
4. Vercel deployt automatisch. Danach:
   - palletto.de mit Cmd+Shift+R prüfen
   - PageSpeed testen: pagespeed.web.dev/?url=https://palletto.de
   - In Google Search Console die sitemap.xml (neu) einreichen

## Wichtig
- Die alten Unterseiten (Blog, Preise, Pillar-Seiten) laufen noch mit altem Design + Tailwind-CDN.
  Die kommen in Phase 2 dran (neues Design + gemeinsames palletto.css + neue Partials _header/_footer).
- Footer-Links zeigen auf /impressum.html /datenschutz.html /agb.html – existieren bereits, passt.
